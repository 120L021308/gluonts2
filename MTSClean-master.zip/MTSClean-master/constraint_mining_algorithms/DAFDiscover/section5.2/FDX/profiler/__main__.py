"""TODO."""

from .profiler import main
from .profiler import core
main()
