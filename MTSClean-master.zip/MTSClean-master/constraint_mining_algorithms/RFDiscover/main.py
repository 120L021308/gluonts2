
import wine as wine

wine.work()
print("wine done")

import rice as rice

rice.work()
print("rice done")

import adult as adult

adult.work()
print("adult done")

import mobileprice as mobileprice

mobileprice.work()
print("mobileprice done")

import heart as heart

heart.work()
print("heart done")
